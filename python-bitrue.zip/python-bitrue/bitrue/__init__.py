"""An unofficial Python wrapper for the Bitrue exchange API v1

.. moduleauthor:: Nathan Demers
.. fork_source:: python-binance-master

"""

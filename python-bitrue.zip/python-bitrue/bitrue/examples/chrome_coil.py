from bitrue.client import Client
from tabulate import tabulate
from pprint import pprint
import time
import configparser

import os
import sys
if __name__ == '__main__':
    from selenium import webdriver

    # client = Client(api_key='2f0982022fc09377f43bc1da4bcb6c2219778ffe256cb96d0e966362908f0d51',
    #                 api_secret='8ec2561b0b457b6b1695f4bc6e95eb11663723fe510e39baed92998187075150',
    #                 )
    # open_orders = client.get_open_orders(symbol='XRPUSDT')
    # order_formatted = client._order_format_print(open_orders, orient='h')
    # print(order_formatted)
    # time.sleep(10000)
    # '''
    #        Windows 7, 8.1, and 10: C:\ Users\<username>\AppData\Local\Google\Chrome\User Data\Default
    #        Mac OS X El Capitan: Users/<username>/Library/Application Support/Google/Chrome/Default
    #        Linux: /home/<username>/.config/google-chrome/default
    #        '''

    #CHROME COIL CHECK
    chrome_coil_extId = 'locbifcbeldmnphbgkdigjmkbfkhbnca'
    chrome_coil = os.path.join(os.getenv('LocalAppData'), r'Google\Chrome\User Data\Default\Extensions')
    chrome_coil_ext = os.path.join(chrome_coil, chrome_coil_extId)

    if os.path.isdir(chrome_coil_ext):
        print(chrome_coil_ext)
    ver = sys.platform
    #FIREFOX COIL CHECK
    coil_ff_extId = 'coilfirefoxextension@coil.com.xpi'
    mozilla_profile = os.path.join(os.getenv('APPDATA'), r'Mozilla\Firefox')
    mozilla_profile_ini = os.path.join(mozilla_profile, r'profiles.ini')
    profile = configparser.ConfigParser()
    profile.read(mozilla_profile_ini)
    FF_PRF_DIR_DEFAULT = os.path.normpath(os.path.join(mozilla_profile, profile.get('Profile0', 'Path')))
    ff_ext_path = os.path.join(FF_PRF_DIR_DEFAULT, 'extensions')
    ff_coil_loc = os.path.join(ff_ext_path,coil_ff_extId)
    ff_coil_enabled = os.path.exists(ff_coil_loc)
    if ff_coil_enabled:
        print(ff_coil_loc)

